sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("askRon.askRonTile.controller.mainView", {
	
		sendEmail :function(){
		    var ronEmail = "ron.nero@sap.com";
			sap.m.URLHelper.triggerEmail(ronEmail, "You have a question", this.byId("textVal").getValue());
		} 
	});
});